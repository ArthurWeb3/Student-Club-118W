# Student-Club-118W
Included - Sitemap, 6 pages, Disney Club 

CSS Info
Font Family: 
Margins:
Picture Borders
H1, H2, H3 

Home - AJ 
Event - Alex 
Links - Brandon
Gallery - Lior 
Sign Up - Lior
About Us - Elias 

Home // Repository 
- Title 
- Links to other in text pages (Event, Links, Gallery, Sign Up, About Us) 
- Dashboard 
- Logo
- Pictures 
- Announcements
- Social Media Links 

Events // Repository 

Links // Repository 

Gallery // Repository

Sign Up // Repository

About Us // Repository